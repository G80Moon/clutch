const LINES = [
  "This site opens back up when your session ends.",
  "It'll still be there in a few minutes. Your assignment won't do itself.",
  "Future you says thanks.",
  "Close this tab and get back to it."
];
const target = decodeURIComponent(location.hash.slice(1) || '');
let host = ''; try { host = new URL(target).hostname.replace(/^www\./, ''); } catch {}
document.getElementById('site').textContent = host ? host + ' is locked' : 'This site is locked';
document.getElementById('site').hidden = false;

(async () => {
  const session = await chrome.runtime.sendMessage({ type: 'blockedHit' });
  if (session && session.attempts > 1) document.getElementById('msg').textContent = LINES[Math.min(session.attempts - 1, LINES.length - 1)];
  const tick = async () => {
    const { session: s } = await chrome.storage.local.get('session');
    if (!s || s.endAt <= Date.now()) {
      document.getElementById('main').classList.add('done');
      document.getElementById('title').textContent = 'Session done. You earned a break.';
      document.getElementById('msg').textContent = host ? `${host} is unlocked. Take 5 minutes, then start another round.` : 'Everything is unlocked.';
      document.getElementById('clock').innerHTML = '00:00<small>unlocked</small>';
      if (target) { const a = document.createElement('a'); a.href = target; a.className = 'btn solid'; a.style.textDecoration = 'none'; a.textContent = 'Go to ' + (host || 'site'); document.getElementById('main').append(a); }
      return;
    }
    const left = s.endAt - Date.now(), m = Math.floor(left / 60000), sec = Math.floor(left / 1000) % 60;
    document.getElementById('clock').innerHTML = `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}<small>left${s.label ? ' on ' + s.label.replace(/[<>&]/g, '') : ' in this session'}</small>`;
    setTimeout(tick, 1000);
  };
  tick();
})();
