const $ = s => document.querySelector(s);
let minutes = 25, timer = null, confirmEnd = false;

async function load() {
  const s = await chrome.storage.local.get(['allow', 'session', 'stats']);
  const st = s.stats || { sessions: 0, minutes: 0, blocked: 0 };
  $('#sSess').textContent = st.sessions; $('#sMin').textContent = st.minutes; $('#sBlk').textContent = st.blocked;
  renderAllow(s.allow || []);
  const run = s.session && s.session.endAt > Date.now();
  $('#idle').hidden = run; $('#running').hidden = !run;
  $('#status').textContent = run ? 'Locked in' : 'Ready';
  clearInterval(timer);
  if (run) {
    const sess = s.session;
    $('#runLabel').textContent = sess.label ? 'Working on: ' + sess.label : 'Study mode is on.';
    $('#attempts').textContent = sess.attempts ? `Blocked ${sess.attempts} distraction${sess.attempts > 1 ? 's' : ''} so far` : '';
    const tick = () => {
      const left = Math.max(0, sess.endAt - Date.now()), m = Math.floor(left / 60000), sec = Math.floor(left / 1000) % 60;
      $('#clock').innerHTML = `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}<small>left</small>`;
      $('#prog').style.width = (100 - left / (sess.minutes * 60000) * 100) + '%';
      if (left <= 0) { clearInterval(timer); setTimeout(load, 800); }
    };
    tick(); timer = setInterval(tick, 500);
  }
}
function renderAllow(list) {
  $('#allow').innerHTML = list.map((d, i) => `<span>${d}<button data-i="${i}" aria-label="Remove ${d}">×</button></span>`).join('');
}
$('#len').onclick = e => { const b = e.target.closest('button'); if (!b) return; minutes = Number(b.dataset.m); document.querySelectorAll('#len button').forEach(x => x.setAttribute('aria-pressed', x === b)); };
$('#start').onclick = async () => { await chrome.runtime.sendMessage({ type: 'start', minutes, label: $('#label').value.trim() }); load(); };
$('#giveup').onclick = async () => {
  if (!confirmEnd) { confirmEnd = true; $('#giveup').textContent = 'Tap again to unlock everything'; setTimeout(() => { confirmEnd = false; $('#giveup').textContent = 'End early'; }, 3000); return; }
  await chrome.runtime.sendMessage({ type: 'stop' }); confirmEnd = false; $('#giveup').textContent = 'End early'; load();
};
$('#allow').onclick = async e => {
  const b = e.target.closest('button[data-i]'); if (!b) return;
  const { allow } = await chrome.storage.local.get('allow'); allow.splice(Number(b.dataset.i), 1);
  renderAllow(await chrome.runtime.sendMessage({ type: 'setAllow', allow }));
};
$('#addForm').onsubmit = async e => {
  e.preventDefault(); const v = $('#addIn').value.trim(); if (!v) return;
  const { allow } = await chrome.storage.local.get('allow');
  renderAllow(await chrome.runtime.sendMessage({ type: 'setAllow', allow: [...(allow || []), v] })); $('#addIn').value = '';
};
$('#reset').onclick = async () => renderAllow(await chrome.runtime.sendMessage({ type: 'resetAllow' }));
load();
