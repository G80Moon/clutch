// Clutch Focus: blocks every site except the allowed list while a study session runs.

const DEFAULT_ALLOW = [
  'morainevalley.edu',          // Canvas, MVConnect, library, tutoring
  'instructure.com',            // Canvas
  'canvaslms.com',
  'login.microsoftonline.com',  // MVCC sign-in (student email is Microsoft)
  'microsoftonline.com',
  'office.com',
  'outlook.office.com',
  'onedrive.live.com',
  'claude.ai',                  // Clutch itself
  'docs.google.com',
  'drive.google.com',
  'wikipedia.org',
  'khanacademy.org',
  'quizlet.com',
  'libretexts.org'
];

const BLOCK_RULE = 1;
const ALLOW_RULE = 2;

async function getState() {
  const s = await chrome.storage.local.get(['allow', 'session', 'stats']);
  return {
    allow: s.allow || DEFAULT_ALLOW,
    session: s.session || null,              // {endAt, minutes, label, startedAt, attempts}
    stats: s.stats || { sessions: 0, minutes: 0, blocked: 0 }
  };
}

function cleanDomain(d) {
  return String(d).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
}

function isAllowed(url, allow) {
  try {
    const u = new URL(url);
    if (!/^https?:$/.test(u.protocol)) return true;
    const host = u.hostname.replace(/^www\./, '');
    return allow.some(d => host === d || host.endsWith('.' + d));
  } catch { return true; }
}

async function applyRules(on, allow) {
  const remove = [BLOCK_RULE, ALLOW_RULE];
  if (!on) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: remove });
    return;
  }
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: remove,
    addRules: [
      {
        id: BLOCK_RULE, priority: 1,
        action: { type: 'redirect', redirect: { regexSubstitution: chrome.runtime.getURL('blocked.html') + '#\\0' } },
        condition: { regexFilter: '^https?://.*', resourceTypes: ['main_frame'] }
      },
      {
        id: ALLOW_RULE, priority: 2,
        action: { type: 'allow' },
        condition: { requestDomains: allow.map(cleanDomain).filter(Boolean), resourceTypes: ['main_frame'] }
      }
    ]
  });
}

// Lock any tab that is already open on a blocked site when a session starts.
async function sweepTabs(allow) {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (t.url && /^https?:/.test(t.url) && !isAllowed(t.url, allow)) {
      chrome.tabs.update(t.id, { url: chrome.runtime.getURL('blocked.html') + '#' + t.url });
    }
  }
}

async function start({ minutes, label }) {
  const { allow } = await getState();
  const now = Date.now();
  const session = { startedAt: now, endAt: now + minutes * 60000, minutes, label: label || '', attempts: 0 };
  await chrome.storage.local.set({ session });
  await applyRules(true, allow);
  await chrome.alarms.clear('end');
  chrome.alarms.create('end', { when: session.endAt });
  chrome.action.setBadgeBackgroundColor({ color: '#2383E2' });
  tickBadge();
  sweepTabs(allow);
  return session;
}

async function stop(completed) {
  const { session, stats } = await getState();
  await applyRules(false);
  await chrome.alarms.clear('end');
  await chrome.alarms.clear('badge');
  chrome.action.setBadgeText({ text: '' });
  if (session) {
    const mins = Math.round((Math.min(Date.now(), session.endAt) - session.startedAt) / 60000);
    stats.minutes += mins;
    if (completed) stats.sessions += 1;
    await chrome.storage.local.set({ stats, session: null, last: { completed, mins, label: session.label, attempts: session.attempts } });
    if (completed) {
      chrome.notifications.create({
        type: 'basic', iconUrl: 'icons/128.png', title: 'Session done',
        message: `${mins} minutes${session.label ? ' on ' + session.label : ''}. Sites are unlocked. Take a 5 minute break.`
      });
    }
  }
}

async function tickBadge() {
  const { session } = await getState();
  if (!session) { chrome.action.setBadgeText({ text: '' }); return; }
  const left = Math.max(0, Math.ceil((session.endAt - Date.now()) / 60000));
  chrome.action.setBadgeText({ text: left + 'm' });
  chrome.alarms.create('badge', { delayInMinutes: 0.5 });
}

chrome.alarms.onAlarm.addListener(a => {
  if (a.name === 'end') stop(true);
  if (a.name === 'badge') tickBadge();
});

// Keep rules in sync if the browser restarts mid-session.
async function resume() {
  const { session, allow } = await getState();
  if (session && session.endAt > Date.now()) { await applyRules(true, allow); chrome.alarms.create('end', { when: session.endAt }); tickBadge(); }
  else if (session) { stop(true); }
  else { applyRules(false); }
}
chrome.runtime.onStartup.addListener(resume);
chrome.runtime.onInstalled.addListener(async () => {
  const s = await chrome.storage.local.get('allow');
  if (!s.allow) await chrome.storage.local.set({ allow: DEFAULT_ALLOW });
  resume();
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    if (msg.type === 'start') reply(await start(msg));
    else if (msg.type === 'stop') { await stop(false); reply(true); }
    else if (msg.type === 'blockedHit') {
      const { session, stats } = await getState();
      if (session) { session.attempts += 1; stats.blocked += 1; await chrome.storage.local.set({ session, stats }); }
      reply(session);
    }
    else if (msg.type === 'setAllow') {
      const allow = [...new Set(msg.allow.map(cleanDomain).filter(Boolean))];
      await chrome.storage.local.set({ allow });
      const { session } = await getState();
      if (session) await applyRules(true, allow);
      reply(allow);
    }
    else if (msg.type === 'resetAllow') { await chrome.storage.local.set({ allow: DEFAULT_ALLOW }); const { session } = await getState(); if (session) await applyRules(true, DEFAULT_ALLOW); reply(DEFAULT_ALLOW); }
    else reply(null);
  })();
  return true;
});
